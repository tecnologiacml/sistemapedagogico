# US-008 · Vínculo histórico (matrículas)

Branch: `vinculo-historico-matricula` (criada a partir da main atualizada)

## Ordem
1. **Supabase**: rode `us008_supabase.sql` no SQL Editor. Veja o resultado da última consulta (alunos / com_matricula / sem_matricula).
2. **Copie os arquivos** do zip por cima do projeto (mesmos caminhos):
   - apps/turmas/: models.py, services.py (novo), forms.py, views.py, urls.py, admin.py, tests_matricula.py (novo)
   - apps/alunos/views.py
   - templates/turmas/matricula_form.html (novo)
   - templates/alunos/aluno_detail.html
3. `python manage.py test` (esperado: 73 + 14 = 87 OK)
4. `python manage.py runserver`: abra a ficha de um aluno, veja o card "Matrículas" e teste "Trocar de turma".
5. git add / commit / push / PR.

Não há migração. config/settings.py e config/urls.py não mudam.
